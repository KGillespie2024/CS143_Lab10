// Kai Gillespie 20240317

public class Task_4 {
 public static void main(String[] args) {
     Cat fluffy = new Cat();
     fluffy.makeNoise();

     Dog rover = new Dog();
     rover.makeNoise();
 }

 public static class Animal {
     public void makeNoise() {
         System.out.println("Generic animal noise.");
     }
 }

 // Define additional classes here
 public static class Cat extends Animal {
     @Override
     public void makeNoise() {
         System.out.println("meow");
     }
 }

 public static class Dog extends Animal {
     @Override
     public void makeNoise() {
         System.out.println("woof");
     }
 }

}
