// Kai Gillespie 20240317
public class Task_6 {
	    	public static void main(String[] args) {
	            // First example
	            String[] names1 = { "Juanita", "Patel" };
	            String[] words1 = { "Good luck", "Fare well" };
	            processStrings(names1, words1);
	            
	            System.out.println(""); //Spacer for readability.
	            
	            // Second example
	            String[] names2 = { "Jim", "Hanna", "Vo" };
	            String[] words2 = { "Eat ", "Well ", "Be ", "Well" };
	            processStrings(names2, words2);
	        }

	        // Calculate the total length of the names in the names array
	        private static int calculateTotalLength(String[] names) {
	            int totalLength = 0;
	            for (String name : names) {
	                totalLength += name.length();
	            }
	            return totalLength;
	        }
	        
	        // Join the words array elements with a space, then convert to uppercase
	        private static String combineWordsToUpper(String[] words) {
	            return String.join(" ", words).toUpperCase().trim();
	        }
	        
	        // Print outside the loop instead of inside the loop.
	        private static void processStrings(String[] names, String[] words) {
	        System.out.println(calculateTotalLength(names)); // Print the total length of the names in the names array
	        System.out.println(combineWordsToUpper(words)); // Print the combined words in the words array in uppercase
	        }
	    }

