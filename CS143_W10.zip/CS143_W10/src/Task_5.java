// Kai Gillespie 20240317
public class Task_5 {
	public static void main(String[] args) {
	     // Example usage:
         double multipleChoiceScore = 40; // out of 50
         double fillInTheBlankScore = 18; // out of 20
         double codingScore = 25; // out of 30
         
	     FinalExam studentExam = new FinalExam(multipleChoiceScore, fillInTheBlankScore, codingScore); 
	     // The	constructor calculates the total score
	     char studentGrade = studentExam.getGrade(); // Uses the method from GradedActivity class
	     
	     System.out.println("The student's letter grade is: " + studentGrade);
	 }
	}
