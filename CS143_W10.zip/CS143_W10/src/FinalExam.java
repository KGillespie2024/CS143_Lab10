// Kai Gillespie 20240317
public class FinalExam extends GradedActivity {
 
 // Constructor taking three scores and computing the total score
 public FinalExam(double multipleChoice, double fillInTheBlank, double coding) {
     // Calculate total score and set it using the setScore method
     double totalScore = multipleChoice + fillInTheBlank + coding;
     setScore(totalScore);
 }
}